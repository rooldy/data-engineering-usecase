"""
Script central de chargement de la couche Bronze

Ce script orchestre le chargement de toutes les tables Bronze
à partir des données RAW (CSV).

Il est destiné à être exécuté :
- en local
- via docker
- via Airflow (PythonOperator ou SparkSubmitOperator)
"""
import sys
import os

PROJECT_ROOT = "/app/src"
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)


from common.spark_session import get_spark_session

# =========================
# IMPORT DES LOADERS BRONZE
# =========================

from bronze.load_clients import load_clients
from bronze.load_produits import load_produits
from bronze.load_commandes import load_commandes
from bronze.load_produits_commandes import load_produits_commandes
from bronze.load_panier import load_panier
from bronze.load_produits_dans_panier import load_produits_dans_panier
from bronze.load_notation_produit import load_notation_produit
from bronze.load_historique_prix_produits import load_historique_prix_produits
from bronze.load_produits_livres import load_produits_livres
from bronze.load_produits_retournes import load_produits_retournes

# Extensions
from bronze.load_paiements import load_paiements
from bronze.load_livraisons_detaillees import load_livraisons_detaillees
from bronze.load_evenements_logs import load_evenements_logs
from bronze.load_promotions import load_promotions
from bronze.load_fournisseurs import load_fournisseurs
from bronze.load_entrepots import load_entrepots
from bronze.load_moyens_paiement import load_moyens_paiement


# =========================
# MAIN
# =========================

def main():
    spark = get_spark_session("Bronze_Layer_Load")

    try:
        print("🚀 Démarrage du chargement BRONZE")

        # ========= DIMENSIONS =========
        load_clients()
        load_produits()
        load_fournisseurs()
        load_entrepots()
        load_promotions()
        load_moyens_paiement()

        # ========= FAITS =========
        load_commandes()
        load_produits_commandes()
        load_panier()
        load_produits_dans_panier()
        load_notation_produit()
        load_paiements()
        load_livraisons_detaillees()
        load_evenements_logs()

        # ========= LOGISTIQUE =========
        load_produits_livres()
        load_produits_retournes()

        # ========= HISTORIQUE =========
        load_historique_prix_produits()

        print("Chargement BRONZE terminé avec succès")

    except Exception as e:
        print("Erreur lors du chargement BRONZE")
        raise e

    finally:
        spark.stop()
        print("SparkSession arrêtée")


# =========================
# POINT D’ENTRÉE
# =========================

if __name__ == "__main__":
    main()
