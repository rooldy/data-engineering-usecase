from pyspark.sql import DataFrame
from pyspark.sql.functions import col

from common.spark_session import get_spark_session
from common.paths import raw_table_path, bronze_table_path


TABLE_NAME = "fournisseurs"


def load_fournisseurs() -> None:
    """
    Charge les données fournisseurs depuis la couche RAW vers la couche BRONZE.
    - Source : CSV
    - Destination : Parquet
    """

    spark = get_spark_session("bronze_load_fournisseurs")

    raw_path = raw_table_path(TABLE_NAME)
    bronze_path = bronze_table_path(TABLE_NAME)

    print(f"[INFO] Lecture des données RAW depuis : {raw_path}")
    print(f"[INFO] Écriture des données BRONZE vers : {bronze_path}")

    # Lecture CSV (RAW)
    df_raw: DataFrame = (
        spark.read
        .option("header", True)
        .option("inferSchema", True)
        .csv(raw_path)
    )

    # (Bronze = données quasi brutes → pas de transformation lourde)
    df_bronze: DataFrame = df_raw.select(
        col("*")
    )

    # Écriture BRONZE
    (
        df_bronze.write
        .mode("overwrite")
        .parquet(bronze_path)
    )

    print(f"[SUCCESS] Table BRONZE '{TABLE_NAME}' chargée avec succès")

    spark.stop()


if __name__ == "__main__":
    load_fournisseurs()
