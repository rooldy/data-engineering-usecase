from pathlib import Path
import os

# Racine du projet
PROJECT_ROOT = Path(
    os.getenv("PROJECT_ROOT", "/app")
)

DATA_ROOT = PROJECT_ROOT / "data"

RAW_PATH = DATA_ROOT / "raw"
BRONZE_PATH = DATA_ROOT / "bronze"
SILVER_PATH = DATA_ROOT / "silver"
GOLD_PATH = DATA_ROOT / "gold"

def raw_path(table_name: str) -> Path:
    return RAW_PATH / table_name

def bronze_path(table_name: str) -> Path:
    return BRONZE_PATH / table_name

def silver_path(table_name: str) -> Path:
    return SILVER_PATH / table_name

def gold_path(table_name: str) -> Path:
    return GOLD_PATH / table_name
